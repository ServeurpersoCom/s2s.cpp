const c = ["native", "off"];
const r = `
class CaptureProcessor extends AudioWorkletProcessor {
	constructor() {
		super();
		this.buffer = new Float32Array(480);
		this.filled = 0;
		this.muted = false;
		this.port.onmessage = (e) => { this.muted = !!e.data.muted; };
	}
	process(inputs) {
		const input = inputs[0] && inputs[0][0];
		if (!input) return true;
		for (let i = 0; i < input.length; i++) {
			this.buffer[this.filled++] = this.muted ? 0 : input[i];
			if (this.filled === this.buffer.length) {
				this.port.postMessage(this.buffer.slice());
				this.filled = 0;
			}
		}
		return true;
	}
}
registerProcessor('s2s-capture', CaptureProcessor);
`, h = `
class PlaybackProcessor extends AudioWorkletProcessor {
	constructor() {
		super();
		this.queue = [];
		this.offset = 0;
		this.played = 0;
		this.generation = 0;
		this.port.onmessage = (e) => {
			if (e.data.flush) {
				this.queue = [];
				this.offset = 0;
			} else if (e.data.reset !== undefined) {
				this.played = 0;
				this.generation = e.data.reset;
			} else {
				this.queue.push(e.data);
			}
		};
	}
	process(_inputs, outputs) {
		const output = outputs[0][0];
		let written = 0;
		while (written < output.length && this.queue.length > 0) {
			const chunk = this.queue[0];
			const take = Math.min(chunk.length - this.offset, output.length - written);
			output.set(chunk.subarray(this.offset, this.offset + take), written);
			this.offset += take;
			written += take;
			this.played += take;
			if (this.offset === chunk.length) {
				this.queue.shift();
				this.offset = 0;
			}
		}
		output.fill(0, written);
		if (written > 0) this.port.postMessage({ played: this.played, generation: this.generation });
		return true;
	}
}
registerProcessor('s2s-playback', PlaybackProcessor);
`;
function l(o) {
  const t = new URL("v1/realtime", o ? o.replace(/\/?$/, "/") : location.href);
  return t.protocol = t.protocol === "https:" ? "wss:" : t.protocol === "http:" ? "ws:" : t.protocol, t.toString();
}
function a(o) {
  return URL.createObjectURL(new Blob([o], { type: "application/javascript" }));
}
function p(o) {
  const t = new Uint8Array(o.length * 2), s = new DataView(t.buffer);
  for (let i = 0; i < o.length; i++) {
    const n = Math.max(-1, Math.min(1, o[i]));
    s.setInt16(i * 2, n * 32767, !0);
  }
  let e = "";
  for (let i = 0; i < t.length; i += 32768)
    e += String.fromCharCode(...t.subarray(i, i + 32768));
  return btoa(e);
}
function u(o) {
  const t = atob(o), s = new Uint8Array(t.length);
  for (let n = 0; n < t.length; n++)
    s[n] = t.charCodeAt(n);
  const e = new DataView(s.buffer), i = new Float32Array(s.length / 2);
  for (let n = 0; n < i.length; n++)
    i[n] = e.getInt16(n * 2, !0) / 32768;
  return i;
}
class d {
  options;
  handlers = {};
  ws = null;
  context = null;
  stream = null;
  capture = null;
  playback = null;
  gain = null;
  volume = 1;
  state = "idle";
  // The answer in flight, measured in samples since its response.created:
  // what the server sent, what the speaker played, and each synthesis unit
  // with the sample where its audio starts. The generation tags the played
  // reports, so a report of a previous answer is ignored.
  generation = 0;
  queuedSamples = 0;
  playedSamples = 0;
  units = [];
  answerDone = !1;
  history = [];
  constructor(t) {
    this.options = t;
  }
  on(t, s) {
    this.handlers[t] = s;
  }
  getState() {
    return this.state;
  }
  // Must be called from a user gesture: browsers refuse both the microphone
  // and an audio context without one.
  async start() {
    if (!this.ws)
      try {
        await this.open();
      } catch (t) {
        const s = t instanceof Error ? `${t.name}: ${t.message}` : String(t);
        throw this.log(`Start failed, ${s}`), this.handlers.error?.(s), this.stop(), t;
      }
  }
  log(t) {
    this.handlers.log?.(t);
  }
  async open() {
    this.log("Start requested"), this.context = new AudioContext({ sampleRate: 24e3 }), await this.context.audioWorklet.addModule(a(r)), await this.context.audioWorklet.addModule(a(h)), this.log(`Audio context at ${this.context.sampleRate} Hz`);
    const t = this.options.echo ?? "native";
    this.stream = await navigator.mediaDevices.getUserMedia({
      audio: {
        echoCancellation: t === "native" ? "all" : !1,
        noiseSuppression: !0,
        autoGainControl: !0,
        channelCount: 1
      }
    }), this.log("Microphone granted"), this.playback = new AudioWorkletNode(this.context, "s2s-playback", {
      numberOfInputs: 0,
      outputChannelCount: [1]
    }), this.playback.port.onmessage = (s) => {
      s.data.generation === this.generation && (this.playedSamples = s.data.played, this.answerDone && this.playedSamples >= this.queuedSamples && (this.closeAnswer(), this.setState("listening")));
    }, this.gain = this.context.createGain(), this.gain.gain.value = this.volume, this.playback.connect(this.gain).connect(this.context.destination), this.capture = new AudioWorkletNode(this.context, "s2s-capture"), this.context.createMediaStreamSource(this.stream).connect(this.capture), this.capture.port.onmessage = (s) => this.sendAudio(s.data), await this.connect(), this.setState("listening");
  }
  stop() {
    this.log("Stop requested"), this.ws?.close(), this.ws = null, this.stream?.getTracks().forEach((t) => t.stop()), this.stream = null, this.context?.close(), this.context = null, this.capture = null, this.playback = null, this.gain = null, this.setState("idle");
  }
  setVolume(t) {
    this.volume = t, this.gain && (this.gain.gain.value = t);
  }
  mute(t) {
    this.capture?.port.postMessage({ muted: t });
  }
  // Client side barge-in: the user took the floor, so playback stops now and
  // the server is told how much was actually heard.
  cancel() {
    this.send({ type: "response.cancel" }), this.flushPlayback();
  }
  getHistory() {
    return this.history;
  }
  // Seeds the conversation, for a host that persisted it or that brings its
  // own context.
  setHistory(t) {
    this.history = t.slice(), this.pushHistory();
  }
  clearHistory() {
    this.log("History cleared"), this.setHistory([]);
  }
  // A field left out keeps its value: an undefined arriving from a cleared
  // input must not erase what the session already runs with.
  update(t) {
    for (const [s, e] of Object.entries(t))
      e !== void 0 && (this.options[s] = e);
    this.sendSessionUpdate();
  }
  setState(t) {
    this.state !== t && (this.state = t, this.handlers.state?.(t));
  }
  send(t) {
    this.ws && this.ws.readyState === WebSocket.OPEN && this.ws.send(JSON.stringify(t));
  }
  sendAudio(t) {
    this.send({ type: "input_audio_buffer.append", audio: p(t) });
  }
  sendSessionUpdate() {
    this.send({
      type: "session.update",
      session: {
        mode: this.options.mode,
        instructions: this.options.instructions,
        llm_url: this.options.llmUrl,
        llm_model: this.options.llmModel,
        llm_key: this.options.llmKey,
        llm_timeout_sec: this.options.llmTimeoutSec,
        sampling: {
          temperature: this.options.sampling?.temperature,
          top_p: this.options.sampling?.topP,
          top_k: this.options.sampling?.topK,
          min_p: this.options.sampling?.minP,
          max_tokens: this.options.sampling?.maxTokens,
          presence_penalty: this.options.sampling?.presencePenalty,
          frequency_penalty: this.options.sampling?.frequencyPenalty,
          seed: this.options.sampling?.seed
        },
        tts: {
          speaker: this.options.tts?.speaker,
          language: this.options.tts?.language,
          min_chars: this.options.tts?.minChars,
          chars_per_second: this.options.tts?.charsPerSecond,
          margin_seconds: this.options.tts?.marginSeconds,
          sampling: {
            temperature: this.options.tts?.sampling?.temperature,
            top_k: this.options.tts?.sampling?.topK,
            top_p: this.options.tts?.sampling?.topP,
            repetition_penalty: this.options.tts?.sampling?.repetitionPenalty,
            subtalker_temperature: this.options.tts?.sampling?.subtalkerTemperature,
            subtalker_top_k: this.options.tts?.sampling?.subtalkerTopK,
            subtalker_top_p: this.options.tts?.sampling?.subtalkerTopP,
            max_new_tokens: this.options.tts?.sampling?.maxNewTokens,
            seed: this.options.tts?.sampling?.seed
          }
        },
        vad: {
          threshold: this.options.vad?.threshold,
          min_speech_ms: this.options.vad?.minSpeechMs,
          min_speech_continuation_ms: this.options.vad?.minSpeechContinuationMs,
          min_silence_ms: this.options.vad?.minSilenceMs,
          speech_pad_ms: this.options.vad?.speechPadMs
        },
        turn: {
          threshold: this.options.turn?.threshold,
          max_wait_ms: this.options.turn?.maxWaitMs
        }
      }
    });
  }
  flushPlayback() {
    this.playback?.port.postMessage({ flush: !0 });
  }
  pushHistory() {
    this.send({ type: "conversation.history", messages: this.history }), this.handlers.history?.(this.history);
  }
  // Closes the answer in flight with what was actually heard. A unit counts
  // once its audio started playing: a barge-in keeps the sentence it cut and
  // drops the ones still queued, so the model never believes it said more.
  closeAnswer() {
    const t = this.units.filter((s) => s.start < this.playedSamples).map((s) => s.text).join(" ").trim();
    this.units = [], this.answerDone = !1, t && (this.history.push({ role: "assistant", content: t }), this.pushHistory());
  }
  connect() {
    return new Promise((t, s) => {
      const e = l(this.options.url), i = new WebSocket(e);
      this.ws = i, this.log(`Connecting to ${e}`), i.onopen = () => {
        this.log("Connected"), this.sendSessionUpdate(), this.pushHistory(), t();
      }, i.onerror = () => {
        this.log(`Connection to ${e} failed`), s(new Error(`cannot reach ${e}`));
      }, i.onclose = (n) => {
        this.log(`Connection closed, code ${n.code}`), this.ws = null, this.setState("idle");
      }, i.onmessage = (n) => this.onServerEvent(n.data);
    });
  }
  onServerEvent(t) {
    let s;
    try {
      s = JSON.parse(t);
    } catch {
      return;
    }
    switch (s.type) {
      case "input_audio_buffer.speech_started":
        (this.state === "speaking" || this.state === "thinking") && (this.flushPlayback(), this.closeAnswer()), this.setState("listening");
        break;
      case "conversation.item.input_audio_transcription.completed":
        {
          const e = String(s.transcript ?? "");
          this.history.push({ role: "user", content: e }), this.handlers.user_text?.(e);
        }
        break;
      case "response.created":
        this.closeAnswer(), this.generation++, this.queuedSamples = 0, this.playedSamples = 0, this.playback?.port.postMessage({ reset: this.generation }), this.setState("thinking");
        break;
      case "response.output_text.delta":
        this.handlers.assistant_delta?.(String(s.delta ?? ""));
        break;
      case "response.output_audio_transcript.delta":
        {
          const e = String(s.delta ?? "");
          this.units.push({ text: e, start: this.queuedSamples }), this.handlers.assistant_text?.(e);
        }
        break;
      case "response.output_audio.delta":
        {
          const e = u(String(s.delta ?? ""));
          this.queuedSamples += e.length, this.playback?.port.postMessage(e), this.setState("speaking");
        }
        break;
      case "response.cancelled":
        this.flushPlayback(), this.closeAnswer(), this.setState("listening");
        break;
      case "response.done":
        this.answerDone = !0, this.playedSamples >= this.queuedSamples && (this.closeAnswer(), this.setState("listening"));
        break;
      case "error":
        {
          const e = s.error;
          this.handlers.error?.(e?.message ?? "unknown error");
        }
        break;
    }
  }
}
export {
  c as ECHO_MODES,
  d as S2S,
  l as realtimeUrl
};
