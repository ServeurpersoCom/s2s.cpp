const g = ["server", "native", "off"], l = "server";
const p = `
class DuplexProcessor extends AudioWorkletProcessor {
	constructor() {
		super();
		this.mic = new Float32Array(480);
		this.ref = new Float32Array(480);
		this.filled = 0;
		this.muted = false;
		this.volume = 1;
		this.queue = [];
		this.offset = 0;
		this.played = 0;
		this.generation = 0;
		this.port.onmessage = (e) => {
			const data = e.data;
			if (data instanceof Float32Array) {
				this.queue.push(data);
			} else if (data.flush) {
				this.queue = [];
				this.offset = 0;
			} else if (data.reset !== undefined) {
				this.played = 0;
				this.generation = data.reset;
			} else if (data.muted !== undefined) {
				this.muted = data.muted;
			} else if (data.volume !== undefined) {
				this.volume = data.volume;
			}
		};
	}
	process(inputs, outputs) {
		const output = outputs[0][0];
		let written = 0;
		while (written < output.length && this.queue.length > 0) {
			const chunk = this.queue[0];
			const take = Math.min(chunk.length - this.offset, output.length - written);
			for (let i = 0; i < take; i++) {
				output[written + i] = chunk[this.offset + i] * this.volume;
			}
			this.offset += take;
			written += take;
			if (this.offset === chunk.length) {
				this.queue.shift();
				this.offset = 0;
			}
		}
		output.fill(0, written);
		if (written > 0) {
			this.played += written;
			this.port.postMessage({ played: this.played, generation: this.generation });
		}

		const input = inputs[0] && inputs[0][0];
		for (let i = 0; i < output.length; i++) {
			this.mic[this.filled] = input && !this.muted ? input[i] : 0;
			this.ref[this.filled] = output[i];
			if (++this.filled === this.mic.length) {
				this.port.postMessage({ mic: this.mic.slice(), ref: this.ref.slice() });
				this.filled = 0;
			}
		}
		return true;
	}
}
registerProcessor('s2s-duplex', DuplexProcessor);
`;
function u() {
  const o = new Intl.DisplayNames(["en"], { type: "language" }), t = navigator.languages.map((s) => o.of(s.split("-")[0])?.toLowerCase());
  return [...new Set(t.filter((s) => !!s))];
}
function c(o) {
  const t = new URL("v1/realtime", o ? o.replace(/\/?$/, "/") : location.href);
  return t.protocol = t.protocol === "https:" ? "wss:" : t.protocol === "http:" ? "ws:" : t.protocol, t.toString();
}
function a(o) {
  const t = o === "server";
  return {
    echoCancellation: o === "native" ? "all" : !1,
    noiseSuppression: !t,
    autoGainControl: !t,
    channelCount: 1
  };
}
function d(o) {
  return URL.createObjectURL(new Blob([o], { type: "application/javascript" }));
}
function h(o) {
  const t = new Uint8Array(o.length * 2), s = new DataView(t.buffer);
  for (let i = 0; i < o.length; i++) {
    const n = Math.max(-1, Math.min(1, o[i]));
    s.setInt16(i * 2, n * 32767, !0);
  }
  let e = "";
  for (let i = 0; i < t.length; i += 32768)
    e += String.fromCharCode(...t.subarray(i, i + 32768));
  return btoa(e);
}
function m(o) {
  const t = atob(o), s = new Uint8Array(t.length);
  for (let n = 0; n < t.length; n++)
    s[n] = t.charCodeAt(n);
  const e = new DataView(s.buffer), i = new Float32Array(s.length / 2);
  for (let n = 0; n < i.length; n++)
    i[n] = e.getInt16(n * 2, !0) / 32768;
  return i;
}
class f {
  options;
  handlers = {};
  ws = null;
  context = null;
  stream = null;
  duplex = null;
  volume = 1;
  state = "idle";
  // The answer in flight, measured in samples since its response.created:
  // what the server sent, what the speaker played, and each synthesis unit
  // with the sample where its audio starts. The generation tags the played
  // reports, so a report of a previous answer is ignored.
  generation = 0;
  queuedSamples = 0;
  playedSamples = 0;
  units = [];
  answerDone = !1;
  answering = !1;
  // between response.created and its close
  history = [];
  userItem = "";
  // the server item of the last user message
  // Bumped by every start and every teardown: a start that a stop overtook,
  // or a socket of an earlier run, sees a different number and backs off.
  run = 0;
  constructor(t) {
    this.options = t;
  }
  on(t, s) {
    this.handlers[t] = s;
  }
  getState() {
    return this.state;
  }
  // Must be called from a user gesture: browsers refuse both the microphone
  // and an audio context without one.
  async start() {
    if (this.context)
      return;
    const t = ++this.run;
    try {
      await this.open(t);
    } catch (s) {
      if (t !== this.run)
        return;
      const e = s instanceof Error ? `${s.name}: ${s.message}` : String(s);
      throw this.log(`Start failed, ${e}`), this.handlers.error?.(e), this.teardown(), s;
    }
  }
  log(t) {
    this.handlers.log?.(t);
  }
  // Every await is a point where a stop may have come in: the run number
  // says so, and what was acquired meanwhile is released on the spot.
  async open(t) {
    if (this.log("Start requested"), !window.isSecureContext) {
      const i = new Error("HTTPS required for the microphone");
      throw i.name = "SecurityError", i;
    }
    const s = new AudioContext({ sampleRate: 24e3 });
    if (this.context = s, await s.audioWorklet.addModule(d(p)), t !== this.run)
      return;
    this.log(`Audio context at ${s.sampleRate} Hz`);
    const e = await navigator.mediaDevices.getUserMedia({
      audio: a(this.echo())
    });
    if (t !== this.run) {
      e.getTracks().forEach((i) => i.stop());
      return;
    }
    this.stream = e, this.log(`Microphone granted, ${this.micApplied()}`), this.duplex = new AudioWorkletNode(s, "s2s-duplex", {
      numberOfInputs: 1,
      numberOfOutputs: 1,
      outputChannelCount: [1]
    }), this.duplex.port.postMessage({ volume: this.volume }), this.duplex.port.onmessage = (i) => {
      if (i.data.mic) {
        this.sendAudio(i.data.mic, i.data.ref);
        return;
      }
      i.data.generation === this.generation && (this.playedSamples = i.data.played, this.answerDone && this.playedSamples >= this.queuedSamples && (this.closeAnswer(), this.setState("listening")));
    }, s.createMediaStreamSource(e).connect(this.duplex), this.duplex.connect(s.destination), await this.connect(t), t === this.run && this.setState("listening");
  }
  stop() {
    this.log("Stop requested"), this.teardown();
  }
  // Releases the socket, the microphone and the audio context, whoever ends
  // the session: the user, a failed start or the server closing. The answer
  // in flight closes first, so what was heard stays in the conversation, and
  // the turn identity goes: the next connection numbers its turns afresh,
  // so no line keeps the item of a turn that no longer exists.
  teardown() {
    this.closeAnswer(), this.userItem = "", this.history = this.history.map(({ role: s, content: e }) => ({ role: s, content: e })), this.run++;
    const t = this.ws;
    this.ws = null, t?.close(), this.stream?.getTracks().forEach((s) => s.stop()), this.stream = null, this.context?.close(), this.context = null, this.duplex = null, this.setState("idle");
  }
  setVolume(t) {
    this.volume = t, this.duplex?.port.postMessage({ volume: t });
  }
  mute(t) {
    this.duplex?.port.postMessage({ muted: t });
  }
  // Client side barge-in: the user took the floor, so playback stops now and
  // the server stops the response. The answer closes right here with what
  // was actually heard; whatever the server still sends for it, audio, text
  // or its terminal, finds it closed and changes nothing.
  cancel() {
    this.send({ type: "response.cancel" }), this.flushPlayback(), this.closeAnswer(), this.setState("listening");
  }
  getHistory() {
    return this.history;
  }
  // Seeds the conversation, for a host that persisted it or that brings its
  // own context.
  setHistory(t) {
    this.history = t.map(({ role: s, content: e }) => ({ role: s, content: e })), this.userItem = "", this.pushHistory();
  }
  // Forgets the conversation. An answer in flight goes with it: the server
  // stops it, the speaker falls silent, and nothing of it is filed or shown,
  // so whatever the server still sends for it finds it closed.
  clearHistory() {
    this.log("History cleared"), this.answering && (this.send({ type: "response.cancel" }), this.flushPlayback(), this.units = [], this.answerDone = !1, this.answering = !1, this.setState("listening")), this.setHistory([]);
  }
  // A key given replaces its value, undefined included, and a field left
  // undefined takes the server default: every session.update describes the
  // whole session. A key left out of options keeps its value.
  update(t) {
    const s = this.echo();
    Object.assign(this.options, t), this.sendSessionUpdate(), this.stream && this.echo() !== s && this.applyEcho();
  }
  // The server switches its canceller on the session.update; the microphone
  // follows here, so the browser processing always matches the method.
  applyEcho() {
    this.stream?.getAudioTracks()[0]?.applyConstraints(a(this.echo())).then(() => this.log(`Microphone switched, ${this.micApplied()}`)).catch((s) => {
      const e = `Microphone switch refused, ${s instanceof Error ? s.message : String(s)}`;
      this.log(e), this.handlers.error?.(e);
    });
  }
  // What really runs on the microphone: the server canceller, and what the
  // browser applies, which is not always what was asked.
  micApplied() {
    const t = this.stream?.getAudioTracks()[0]?.getSettings();
    return `server echo cancellation ${this.echo() === "server"}, browser echo cancellation ${t?.echoCancellation}, noise suppression ${t?.noiseSuppression}, gain control ${t?.autoGainControl}`;
  }
  setState(t) {
    this.state !== t && (this.state = t, this.handlers.state?.(t));
  }
  send(t) {
    this.ws && this.ws.readyState === WebSocket.OPEN && this.ws.send(JSON.stringify(t));
  }
  // The reference only travels to a server canceller, and only when the
  // frame played something: silence is what its absence means.
  sendAudio(t, s) {
    const e = this.echo() === "server" && s.some((i) => i !== 0);
    this.send({
      type: "input_audio_buffer.append",
      audio: h(t),
      ...e ? { reference: h(s) } : {}
    });
  }
  echo() {
    return this.options.echo ?? l;
  }
  sendSessionUpdate() {
    this.send({
      type: "session.update",
      session: {
        mode: this.options.mode,
        echo: this.echo(),
        instructions: this.options.instructions,
        llm_url: this.options.llmUrl,
        llm_model: this.options.llmModel,
        llm_key: this.options.llmKey,
        llm_timeout_sec: this.options.llmTimeoutSec,
        tools: this.options.tools,
        mcp: this.options.mcp,
        max_rounds: this.options.maxRounds,
        tool_timeout_sec: this.options.toolTimeoutSec,
        sampling: {
          temperature: this.options.sampling?.temperature,
          top_p: this.options.sampling?.topP,
          top_k: this.options.sampling?.topK,
          min_p: this.options.sampling?.minP,
          max_tokens: this.options.sampling?.maxTokens,
          presence_penalty: this.options.sampling?.presencePenalty,
          frequency_penalty: this.options.sampling?.frequencyPenalty,
          seed: this.options.sampling?.seed,
          reasoning_effort: this.options.sampling?.reasoningEffort
        },
        tts: {
          voice: this.options.tts?.voice,
          language: this.options.tts?.language,
          browser_languages: u(),
          min_chars: this.options.tts?.minChars,
          chars_per_second: this.options.tts?.charsPerSecond,
          margin_seconds: this.options.tts?.marginSeconds,
          sampling: {
            temperature: this.options.tts?.sampling?.temperature,
            top_k: this.options.tts?.sampling?.topK,
            top_p: this.options.tts?.sampling?.topP,
            repetition_penalty: this.options.tts?.sampling?.repetitionPenalty,
            subtalker_temperature: this.options.tts?.sampling?.subtalkerTemperature,
            subtalker_top_k: this.options.tts?.sampling?.subtalkerTopK,
            subtalker_top_p: this.options.tts?.sampling?.subtalkerTopP,
            max_new_tokens: this.options.tts?.sampling?.maxNewTokens,
            seed: this.options.tts?.sampling?.seed
          }
        },
        vad: {
          neg_threshold: this.options.vad?.negThreshold,
          threshold: this.options.vad?.threshold,
          min_speech_ms: this.options.vad?.minSpeechMs,
          barge_in_ms: this.options.vad?.bargeInMs,
          min_silence_ms: this.options.vad?.minSilenceMs,
          min_speech_continuation_ms: this.options.vad?.minSpeechContinuationMs,
          speech_pad_ms: this.options.vad?.speechPadMs
        },
        turn: {
          threshold: this.options.turn?.threshold,
          incomplete_delay_ms: this.options.turn?.incompleteDelayMs,
          max_wait_ms: this.options.turn?.maxWaitMs,
          reopen_grace_ms: this.options.turn?.graceMs
        }
      }
    });
  }
  flushPlayback() {
    this.duplex?.port.postMessage({ flush: !0 });
  }
  pushHistory() {
    this.send({ type: "conversation.history", messages: this.history }), this.handlers.history?.(this.history);
  }
  // Closes the answer in flight with what was actually heard. A unit counts
  // once its audio started playing: a barge-in keeps the sentence it cut and
  // drops the ones still queued, so the model never believes it said more.
  // An answer with nothing heard is not filed, empty or cut before a word,
  // and the turn it answered reaches the server joined to the next one: a
  // silence filed as an answer is one the model imitates. Every close
  // pushes the list.
  closeAnswer() {
    if (!this.answering)
      return;
    const t = this.answerDone, s = this.units.filter((e) => e.start < this.playedSamples).map((e) => e.text).join(" ").trim();
    this.units = [], this.answerDone = !1, this.answering = !1, s && this.history.push({ role: "assistant", content: s }), t && this.handlers.assistant_done?.(), this.pushHistory();
  }
  connect(t) {
    return new Promise((s, e) => {
      const i = c(this.options.url), n = new WebSocket(i);
      this.ws = n, this.log(`Connecting to ${i}`), n.onopen = () => {
        this.log("Connected"), this.sendSessionUpdate(), this.pushHistory(), s();
      }, n.onerror = () => {
        this.log(`Connection to ${i} failed`), e(new Error(`cannot reach ${i}`));
      }, n.onclose = (r) => {
        n !== this.ws || t !== this.run || (this.log(`Connection closed, code ${r.code}`), r.wasClean || this.handlers.error?.(`Connection lost, code ${r.code}`), this.teardown());
      }, n.onmessage = (r) => this.onServerEvent(r.data);
    });
  }
  onServerEvent(t) {
    let s;
    try {
      s = JSON.parse(t);
    } catch {
      return;
    }
    switch (s.type) {
      case "input_audio_buffer.speech_started":
        (this.state === "speaking" || this.state === "thinking") && (this.flushPlayback(), this.closeAnswer()), this.setState("listening");
        break;
      case "conversation.item.input_audio_transcription.completed":
        {
          const e = String(s.transcript ?? ""), i = String(s.item_id ?? ""), n = this.history[this.history.length - 1], r = i !== "" && i === this.userItem && n?.role === "user";
          r ? n.content = e : this.history.push({ role: "user", content: e, item: i }), this.userItem = i, this.handlers.user_text?.(e, r);
        }
        break;
      case "response.created":
        this.closeAnswer(), this.answering = !0, this.answerDone = !1, this.generation++, this.queuedSamples = 0, this.playedSamples = 0, this.duplex?.port.postMessage({ reset: this.generation }), this.setState("thinking");
        break;
      // An answer the client already closed takes nothing more.
      case "response.output_text.delta":
        this.answering && this.handlers.assistant_delta?.(String(s.delta ?? ""));
        break;
      case "response.output_audio_transcript.delta":
        if (this.answering) {
          const e = String(s.delta ?? "");
          this.units.push({ text: e, start: this.queuedSamples }), this.handlers.assistant_text?.(e, Number(s.text_end ?? 0));
        }
        break;
      case "response.output_audio.delta":
        if (this.answering) {
          const e = m(String(s.delta ?? ""));
          this.queuedSamples += e.length, this.duplex?.port.postMessage(e), this.setState("speaking");
        }
        break;
      case "response.cancelled":
        this.flushPlayback(), this.closeAnswer(), this.setState("listening");
        break;
      case "response.done":
        this.answerDone = !0, this.playedSamples >= this.queuedSamples && (this.closeAnswer(), this.setState("listening"));
        break;
      case "error":
        {
          const e = s.error;
          this.handlers.error?.(e?.message ?? "unknown error");
        }
        break;
    }
  }
}
export {
  l as ECHO_DEFAULT,
  g as ECHO_MODES,
  f as S2S
};
