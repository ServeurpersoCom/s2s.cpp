const m = ["server", "native", "off"], l = "server";
const p = `
class DuplexProcessor extends AudioWorkletProcessor {
	constructor() {
		super();
		this.mic = new Float32Array(480);
		this.ref = new Float32Array(480);
		this.filled = 0;
		this.muted = false;
		this.volume = 1;
		this.queue = [];
		this.offset = 0;
		this.played = 0;
		this.generation = 0;
		this.port.onmessage = (e) => {
			const data = e.data;
			if (data instanceof Float32Array) {
				this.queue.push(data);
			} else if (data.flush) {
				this.queue = [];
				this.offset = 0;
			} else if (data.reset !== undefined) {
				this.played = 0;
				this.generation = data.reset;
			} else if (data.muted !== undefined) {
				this.muted = data.muted;
			} else if (data.volume !== undefined) {
				this.volume = data.volume;
			}
		};
	}
	process(inputs, outputs) {
		const output = outputs[0][0];
		let written = 0;
		while (written < output.length && this.queue.length > 0) {
			const chunk = this.queue[0];
			const take = Math.min(chunk.length - this.offset, output.length - written);
			for (let i = 0; i < take; i++) {
				output[written + i] = chunk[this.offset + i] * this.volume;
			}
			this.offset += take;
			written += take;
			if (this.offset === chunk.length) {
				this.queue.shift();
				this.offset = 0;
			}
		}
		output.fill(0, written);
		if (written > 0) {
			this.played += written;
			this.port.postMessage({ played: this.played, generation: this.generation });
		}

		const input = inputs[0] && inputs[0][0];
		for (let i = 0; i < output.length; i++) {
			this.mic[this.filled] = input && !this.muted ? input[i] : 0;
			this.ref[this.filled] = output[i];
			if (++this.filled === this.mic.length) {
				this.port.postMessage({ mic: this.mic.slice(), ref: this.ref.slice() });
				this.filled = 0;
			}
		}
		return true;
	}
}
registerProcessor('s2s-duplex', DuplexProcessor);
`;
function u(o) {
  const t = new URL("v1/realtime", o ? o.replace(/\/?$/, "/") : location.href);
  return t.protocol = t.protocol === "https:" ? "wss:" : t.protocol === "http:" ? "ws:" : t.protocol, t.toString();
}
function a(o) {
  const t = o === "server";
  return {
    echoCancellation: o === "native" ? "all" : !1,
    noiseSuppression: !t,
    autoGainControl: !t,
    channelCount: 1
  };
}
function c(o) {
  return URL.createObjectURL(new Blob([o], { type: "application/javascript" }));
}
function h(o) {
  const t = new Uint8Array(o.length * 2), s = new DataView(t.buffer);
  for (let e = 0; e < o.length; e++) {
    const n = Math.max(-1, Math.min(1, o[e]));
    s.setInt16(e * 2, n * 32767, !0);
  }
  let i = "";
  for (let e = 0; e < t.length; e += 32768)
    i += String.fromCharCode(...t.subarray(e, e + 32768));
  return btoa(i);
}
function d(o) {
  const t = atob(o), s = new Uint8Array(t.length);
  for (let n = 0; n < t.length; n++)
    s[n] = t.charCodeAt(n);
  const i = new DataView(s.buffer), e = new Float32Array(s.length / 2);
  for (let n = 0; n < e.length; n++)
    e[n] = i.getInt16(n * 2, !0) / 32768;
  return e;
}
class g {
  options;
  handlers = {};
  ws = null;
  context = null;
  stream = null;
  duplex = null;
  volume = 1;
  state = "idle";
  // The answer in flight, measured in samples since its response.created:
  // what the server sent, what the speaker played, and each synthesis unit
  // with the sample where its audio starts. The generation tags the played
  // reports, so a report of a previous answer is ignored.
  generation = 0;
  queuedSamples = 0;
  playedSamples = 0;
  units = [];
  answerDone = !1;
  answering = !1;
  // between response.created and its close
  history = [];
  userItem = "";
  // the server item of the last user message
  // Bumped by every start and every teardown: a start that a stop overtook,
  // or a socket of an earlier run, sees a different number and backs off.
  run = 0;
  constructor(t) {
    this.options = t;
  }
  on(t, s) {
    this.handlers[t] = s;
  }
  getState() {
    return this.state;
  }
  // Must be called from a user gesture: browsers refuse both the microphone
  // and an audio context without one.
  async start() {
    if (this.context)
      return;
    const t = ++this.run;
    try {
      await this.open(t);
    } catch (s) {
      if (t !== this.run)
        return;
      const i = s instanceof Error ? `${s.name}: ${s.message}` : String(s);
      throw this.log(`Start failed, ${i}`), this.handlers.error?.(i), this.teardown(), s;
    }
  }
  log(t) {
    this.handlers.log?.(t);
  }
  // Every await is a point where a stop may have come in: the run number
  // says so, and what was acquired meanwhile is released on the spot.
  async open(t) {
    this.log("Start requested");
    const s = new AudioContext({ sampleRate: 24e3 });
    if (this.context = s, await s.audioWorklet.addModule(c(p)), t !== this.run)
      return;
    this.log(`Audio context at ${s.sampleRate} Hz`);
    const i = await navigator.mediaDevices.getUserMedia({
      audio: a(this.echo())
    });
    if (t !== this.run) {
      i.getTracks().forEach((e) => e.stop());
      return;
    }
    this.stream = i, this.log(`Microphone granted, ${this.micApplied()}`), this.duplex = new AudioWorkletNode(s, "s2s-duplex", {
      numberOfInputs: 1,
      numberOfOutputs: 1,
      outputChannelCount: [1]
    }), this.duplex.port.postMessage({ volume: this.volume }), this.duplex.port.onmessage = (e) => {
      if (e.data.mic) {
        this.sendAudio(e.data.mic, e.data.ref);
        return;
      }
      e.data.generation === this.generation && (this.playedSamples = e.data.played, this.answerDone && this.playedSamples >= this.queuedSamples && (this.closeAnswer(), this.setState("listening")));
    }, s.createMediaStreamSource(i).connect(this.duplex), this.duplex.connect(s.destination), await this.connect(t), t === this.run && this.setState("listening");
  }
  stop() {
    this.log("Stop requested"), this.teardown();
  }
  // Releases the socket, the microphone and the audio context, whoever ends
  // the session: the user, a failed start or the server closing. The answer
  // in flight closes first, so what was heard stays in the conversation, and
  // the turn identity goes: the next connection numbers its turns afresh.
  teardown() {
    this.closeAnswer(), this.userItem = "", this.run++;
    const t = this.ws;
    this.ws = null, t?.close(), this.stream?.getTracks().forEach((s) => s.stop()), this.stream = null, this.context?.close(), this.context = null, this.duplex = null, this.setState("idle");
  }
  setVolume(t) {
    this.volume = t, this.duplex?.port.postMessage({ volume: t });
  }
  mute(t) {
    this.duplex?.port.postMessage({ muted: t });
  }
  // Client side barge-in: the user took the floor, so playback stops now and
  // the server stops the response. The answer keeps what was actually heard
  // once the server confirms with response.cancelled.
  cancel() {
    this.send({ type: "response.cancel" }), this.flushPlayback();
  }
  getHistory() {
    return this.history;
  }
  // Seeds the conversation, for a host that persisted it or that brings its
  // own context.
  setHistory(t) {
    this.history = t.slice(), this.userItem = "", this.pushHistory();
  }
  clearHistory() {
    this.log("History cleared"), this.setHistory([]);
  }
  // A key given replaces its value, undefined included, and a field left
  // undefined takes the server default: every session.update describes the
  // whole session. A key left out of options keeps its value.
  update(t) {
    const s = this.echo();
    Object.assign(this.options, t), this.sendSessionUpdate(), this.stream && this.echo() !== s && this.applyEcho();
  }
  // The server switches its canceller on the session.update; the microphone
  // follows here, so the browser processing always matches the method.
  applyEcho() {
    this.stream?.getAudioTracks()[0]?.applyConstraints(a(this.echo())).then(() => this.log(`Microphone switched, ${this.micApplied()}`)).catch(
      (s) => this.log(`Microphone switch refused, ${s instanceof Error ? s.message : String(s)}`)
    );
  }
  // What the browser really runs on the microphone, which is not always
  // what was asked.
  micApplied() {
    const t = this.stream?.getAudioTracks()[0]?.getSettings();
    return `echo ${this.echo()}, browser echo cancellation ${t?.echoCancellation}, noise suppression ${t?.noiseSuppression}, gain control ${t?.autoGainControl}`;
  }
  setState(t) {
    this.state !== t && (this.state = t, this.handlers.state?.(t));
  }
  send(t) {
    this.ws && this.ws.readyState === WebSocket.OPEN && this.ws.send(JSON.stringify(t));
  }
  // The reference only travels to a server canceller, and only when the
  // frame played something: silence is what its absence means.
  sendAudio(t, s) {
    const i = this.echo() === "server" && s.some((e) => e !== 0);
    this.send({
      type: "input_audio_buffer.append",
      audio: h(t),
      ...i ? { reference: h(s) } : {}
    });
  }
  echo() {
    return this.options.echo ?? l;
  }
  sendSessionUpdate() {
    this.send({
      type: "session.update",
      session: {
        mode: this.options.mode,
        echo: this.echo(),
        instructions: this.options.instructions,
        llm_url: this.options.llmUrl,
        llm_model: this.options.llmModel,
        llm_key: this.options.llmKey,
        llm_timeout_sec: this.options.llmTimeoutSec,
        sampling: {
          temperature: this.options.sampling?.temperature,
          top_p: this.options.sampling?.topP,
          top_k: this.options.sampling?.topK,
          min_p: this.options.sampling?.minP,
          max_tokens: this.options.sampling?.maxTokens,
          presence_penalty: this.options.sampling?.presencePenalty,
          frequency_penalty: this.options.sampling?.frequencyPenalty,
          seed: this.options.sampling?.seed,
          reasoning_effort: this.options.sampling?.reasoningEffort
        },
        tts: {
          speaker: this.options.tts?.speaker,
          language: this.options.tts?.language,
          min_chars: this.options.tts?.minChars,
          chars_per_second: this.options.tts?.charsPerSecond,
          margin_seconds: this.options.tts?.marginSeconds,
          sampling: {
            temperature: this.options.tts?.sampling?.temperature,
            top_k: this.options.tts?.sampling?.topK,
            top_p: this.options.tts?.sampling?.topP,
            repetition_penalty: this.options.tts?.sampling?.repetitionPenalty,
            subtalker_temperature: this.options.tts?.sampling?.subtalkerTemperature,
            subtalker_top_k: this.options.tts?.sampling?.subtalkerTopK,
            subtalker_top_p: this.options.tts?.sampling?.subtalkerTopP,
            max_new_tokens: this.options.tts?.sampling?.maxNewTokens,
            seed: this.options.tts?.sampling?.seed
          }
        },
        vad: {
          threshold: this.options.vad?.threshold,
          min_speech_ms: this.options.vad?.minSpeechMs,
          min_speech_continuation_ms: this.options.vad?.minSpeechContinuationMs,
          min_silence_ms: this.options.vad?.minSilenceMs,
          speech_pad_ms: this.options.vad?.speechPadMs
        },
        turn: {
          threshold: this.options.turn?.threshold,
          max_wait_ms: this.options.turn?.maxWaitMs,
          reopen_grace_ms: this.options.turn?.graceMs
        }
      }
    });
  }
  flushPlayback() {
    this.duplex?.port.postMessage({ flush: !0 });
  }
  pushHistory() {
    this.send({ type: "conversation.history", messages: this.history }), this.handlers.history?.(this.history);
  }
  // Closes the answer in flight with what was actually heard. A unit counts
  // once its audio started playing: a barge-in keeps the sentence it cut and
  // drops the ones still queued, so the model never believes it said more.
  // Every close pushes the list, heard or not: a turn left without an answer
  // still reaches the server, which joins it to the next one.
  closeAnswer() {
    if (!this.answering)
      return;
    const t = this.units.filter((s) => s.start < this.playedSamples).map((s) => s.text).join(" ").trim();
    this.units = [], this.answerDone = !1, this.answering = !1, t && this.history.push({ role: "assistant", content: t }), this.pushHistory();
  }
  connect(t) {
    return new Promise((s, i) => {
      const e = u(this.options.url), n = new WebSocket(e);
      this.ws = n, this.log(`Connecting to ${e}`), n.onopen = () => {
        this.log("Connected"), this.sendSessionUpdate(), this.pushHistory(), s();
      }, n.onerror = () => {
        this.log(`Connection to ${e} failed`), i(new Error(`cannot reach ${e}`));
      }, n.onclose = (r) => {
        n !== this.ws || t !== this.run || (this.log(`Connection closed, code ${r.code}`), this.teardown());
      }, n.onmessage = (r) => this.onServerEvent(r.data);
    });
  }
  onServerEvent(t) {
    let s;
    try {
      s = JSON.parse(t);
    } catch {
      return;
    }
    switch (s.type) {
      case "input_audio_buffer.speech_started":
        (this.state === "speaking" || this.state === "thinking") && (this.flushPlayback(), this.closeAnswer()), this.setState("listening");
        break;
      case "conversation.item.input_audio_transcription.completed":
        {
          const i = String(s.transcript ?? ""), e = String(s.item_id ?? ""), n = this.history[this.history.length - 1], r = e !== "" && e === this.userItem && n?.role === "user";
          r ? n.content = i : this.history.push({ role: "user", content: i }), this.userItem = e, this.handlers.user_text?.(i, r);
        }
        break;
      case "response.created":
        this.closeAnswer(), this.answering = !0, this.generation++, this.queuedSamples = 0, this.playedSamples = 0, this.duplex?.port.postMessage({ reset: this.generation }), this.setState("thinking");
        break;
      case "response.output_text.delta":
        this.handlers.assistant_delta?.(String(s.delta ?? ""));
        break;
      case "response.output_audio_transcript.delta":
        {
          const i = String(s.delta ?? "");
          this.units.push({ text: i, start: this.queuedSamples }), this.handlers.assistant_text?.(i, Number(s.text_end ?? 0));
        }
        break;
      case "response.output_audio.delta":
        {
          const i = d(String(s.delta ?? ""));
          this.queuedSamples += i.length, this.duplex?.port.postMessage(i), this.setState("speaking");
        }
        break;
      case "response.cancelled":
        this.flushPlayback(), this.closeAnswer(), this.setState("listening");
        break;
      case "response.done":
        this.answerDone = !0, this.playedSamples >= this.queuedSamples && (this.closeAnswer(), this.setState("listening"));
        break;
      case "error":
        {
          const i = s.error;
          this.handlers.error?.(i?.message ?? "unknown error");
        }
        break;
    }
  }
}
export {
  l as ECHO_DEFAULT,
  m as ECHO_MODES,
  g as S2S
};
