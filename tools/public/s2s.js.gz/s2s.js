const d = ["server", "native", "off"], h = "server";
const l = `
class DuplexProcessor extends AudioWorkletProcessor {
	constructor() {
		super();
		this.mic = new Float32Array(480);
		this.ref = new Float32Array(480);
		this.filled = 0;
		this.muted = false;
		this.volume = 1;
		this.queue = [];
		this.offset = 0;
		this.played = 0;
		this.generation = 0;
		this.port.onmessage = (e) => {
			const data = e.data;
			if (data instanceof Float32Array) {
				this.queue.push(data);
			} else if (data.flush) {
				this.queue = [];
				this.offset = 0;
			} else if (data.reset !== undefined) {
				this.played = 0;
				this.generation = data.reset;
			} else if (data.muted !== undefined) {
				this.muted = data.muted;
			} else if (data.volume !== undefined) {
				this.volume = data.volume;
			}
		};
	}
	process(inputs, outputs) {
		const output = outputs[0][0];
		let written = 0;
		while (written < output.length && this.queue.length > 0) {
			const chunk = this.queue[0];
			const take = Math.min(chunk.length - this.offset, output.length - written);
			for (let i = 0; i < take; i++) {
				output[written + i] = chunk[this.offset + i] * this.volume;
			}
			this.offset += take;
			written += take;
			if (this.offset === chunk.length) {
				this.queue.shift();
				this.offset = 0;
			}
		}
		output.fill(0, written);
		if (written > 0) {
			this.played += written;
			this.port.postMessage({ played: this.played, generation: this.generation });
		}

		const input = inputs[0] && inputs[0][0];
		for (let i = 0; i < output.length; i++) {
			this.mic[this.filled] = input && !this.muted ? input[i] : 0;
			this.ref[this.filled] = output[i];
			if (++this.filled === this.mic.length) {
				this.port.postMessage({ mic: this.mic.slice(), ref: this.ref.slice() });
				this.filled = 0;
			}
		}
		return true;
	}
}
registerProcessor('s2s-duplex', DuplexProcessor);
`;
function p(o) {
  const t = new URL("v1/realtime", o ? o.replace(/\/?$/, "/") : location.href);
  return t.protocol = t.protocol === "https:" ? "wss:" : t.protocol === "http:" ? "ws:" : t.protocol, t.toString();
}
function a(o) {
  const t = o === "server";
  return {
    echoCancellation: o === "native" ? "all" : !1,
    noiseSuppression: !t,
    autoGainControl: !t,
    channelCount: 1
  };
}
function c(o) {
  return URL.createObjectURL(new Blob([o], { type: "application/javascript" }));
}
function r(o) {
  const t = new Uint8Array(o.length * 2), e = new DataView(t.buffer);
  for (let i = 0; i < o.length; i++) {
    const n = Math.max(-1, Math.min(1, o[i]));
    e.setInt16(i * 2, n * 32767, !0);
  }
  let s = "";
  for (let i = 0; i < t.length; i += 32768)
    s += String.fromCharCode(...t.subarray(i, i + 32768));
  return btoa(s);
}
function u(o) {
  const t = atob(o), e = new Uint8Array(t.length);
  for (let n = 0; n < t.length; n++)
    e[n] = t.charCodeAt(n);
  const s = new DataView(e.buffer), i = new Float32Array(e.length / 2);
  for (let n = 0; n < i.length; n++)
    i[n] = s.getInt16(n * 2, !0) / 32768;
  return i;
}
class m {
  options;
  handlers = {};
  ws = null;
  context = null;
  stream = null;
  duplex = null;
  volume = 1;
  state = "idle";
  // The answer in flight, measured in samples since its response.created:
  // what the server sent, what the speaker played, and each synthesis unit
  // with the sample where its audio starts. The generation tags the played
  // reports, so a report of a previous answer is ignored.
  generation = 0;
  queuedSamples = 0;
  playedSamples = 0;
  units = [];
  answerDone = !1;
  history = [];
  constructor(t) {
    this.options = t;
  }
  on(t, e) {
    this.handlers[t] = e;
  }
  getState() {
    return this.state;
  }
  // Must be called from a user gesture: browsers refuse both the microphone
  // and an audio context without one.
  async start() {
    if (!this.ws)
      try {
        await this.open();
      } catch (t) {
        const e = t instanceof Error ? `${t.name}: ${t.message}` : String(t);
        throw this.log(`Start failed, ${e}`), this.handlers.error?.(e), this.stop(), t;
      }
  }
  log(t) {
    this.handlers.log?.(t);
  }
  async open() {
    this.log("Start requested"), this.context = new AudioContext({ sampleRate: 24e3 }), await this.context.audioWorklet.addModule(c(l)), this.log(`Audio context at ${this.context.sampleRate} Hz`), this.stream = await navigator.mediaDevices.getUserMedia({ audio: a(this.echo()) }), this.log(`Microphone granted, ${this.micApplied()}`), this.duplex = new AudioWorkletNode(this.context, "s2s-duplex", {
      numberOfInputs: 1,
      numberOfOutputs: 1,
      outputChannelCount: [1]
    }), this.duplex.port.postMessage({ volume: this.volume }), this.duplex.port.onmessage = (t) => {
      if (t.data.mic) {
        this.sendAudio(t.data.mic, t.data.ref);
        return;
      }
      t.data.generation === this.generation && (this.playedSamples = t.data.played, this.answerDone && this.playedSamples >= this.queuedSamples && (this.closeAnswer(), this.setState("listening")));
    }, this.context.createMediaStreamSource(this.stream).connect(this.duplex), this.duplex.connect(this.context.destination), await this.connect(), this.setState("listening");
  }
  stop() {
    this.log("Stop requested"), this.ws?.close(), this.ws = null, this.stream?.getTracks().forEach((t) => t.stop()), this.stream = null, this.context?.close(), this.context = null, this.duplex = null, this.setState("idle");
  }
  setVolume(t) {
    this.volume = t, this.duplex?.port.postMessage({ volume: t });
  }
  mute(t) {
    this.duplex?.port.postMessage({ muted: t });
  }
  // Client side barge-in: the user took the floor, so playback stops now and
  // the server stops the response. The answer keeps what was actually heard
  // once the server confirms with response.cancelled.
  cancel() {
    this.send({ type: "response.cancel" }), this.flushPlayback();
  }
  getHistory() {
    return this.history;
  }
  // Seeds the conversation, for a host that persisted it or that brings its
  // own context.
  setHistory(t) {
    this.history = t.slice(), this.pushHistory();
  }
  clearHistory() {
    this.log("History cleared"), this.setHistory([]);
  }
  // A field left out keeps its value: an undefined arriving from a cleared
  // input must not erase what the session already runs with.
  update(t) {
    const e = this.echo();
    for (const [s, i] of Object.entries(t))
      i !== void 0 && (this.options[s] = i);
    this.sendSessionUpdate(), this.stream && this.echo() !== e && this.applyEcho();
  }
  // The server switches its canceller on the session.update; the microphone
  // follows here, so the browser processing always matches the method.
  applyEcho() {
    this.stream?.getAudioTracks()[0]?.applyConstraints(a(this.echo())).then(() => this.log(`Microphone switched, ${this.micApplied()}`)).catch(
      (e) => this.log(`Microphone switch refused, ${e instanceof Error ? e.message : String(e)}`)
    );
  }
  // What the browser really runs on the microphone, which is not always
  // what was asked.
  micApplied() {
    const t = this.stream?.getAudioTracks()[0]?.getSettings();
    return `echo ${this.echo()}, browser echo cancellation ${t?.echoCancellation}, noise suppression ${t?.noiseSuppression}, gain control ${t?.autoGainControl}`;
  }
  setState(t) {
    this.state !== t && (this.state = t, this.handlers.state?.(t));
  }
  send(t) {
    this.ws && this.ws.readyState === WebSocket.OPEN && this.ws.send(JSON.stringify(t));
  }
  // The reference only travels to a server canceller, and only when the
  // frame played something: silence is what its absence means.
  sendAudio(t, e) {
    const s = this.echo() === "server" && e.some((i) => i !== 0);
    this.send({
      type: "input_audio_buffer.append",
      audio: r(t),
      ...s ? { reference: r(e) } : {}
    });
  }
  echo() {
    return this.options.echo ?? h;
  }
  sendSessionUpdate() {
    this.send({
      type: "session.update",
      session: {
        mode: this.options.mode,
        echo: this.echo(),
        instructions: this.options.instructions,
        llm_url: this.options.llmUrl,
        llm_model: this.options.llmModel,
        llm_key: this.options.llmKey,
        llm_timeout_sec: this.options.llmTimeoutSec,
        sampling: {
          temperature: this.options.sampling?.temperature,
          top_p: this.options.sampling?.topP,
          top_k: this.options.sampling?.topK,
          min_p: this.options.sampling?.minP,
          max_tokens: this.options.sampling?.maxTokens,
          presence_penalty: this.options.sampling?.presencePenalty,
          frequency_penalty: this.options.sampling?.frequencyPenalty,
          seed: this.options.sampling?.seed
        },
        tts: {
          speaker: this.options.tts?.speaker,
          language: this.options.tts?.language,
          min_chars: this.options.tts?.minChars,
          chars_per_second: this.options.tts?.charsPerSecond,
          margin_seconds: this.options.tts?.marginSeconds,
          sampling: {
            temperature: this.options.tts?.sampling?.temperature,
            top_k: this.options.tts?.sampling?.topK,
            top_p: this.options.tts?.sampling?.topP,
            repetition_penalty: this.options.tts?.sampling?.repetitionPenalty,
            subtalker_temperature: this.options.tts?.sampling?.subtalkerTemperature,
            subtalker_top_k: this.options.tts?.sampling?.subtalkerTopK,
            subtalker_top_p: this.options.tts?.sampling?.subtalkerTopP,
            max_new_tokens: this.options.tts?.sampling?.maxNewTokens,
            seed: this.options.tts?.sampling?.seed
          }
        },
        vad: {
          threshold: this.options.vad?.threshold,
          min_speech_ms: this.options.vad?.minSpeechMs,
          min_speech_continuation_ms: this.options.vad?.minSpeechContinuationMs,
          min_silence_ms: this.options.vad?.minSilenceMs,
          speech_pad_ms: this.options.vad?.speechPadMs
        },
        turn: {
          threshold: this.options.turn?.threshold,
          max_wait_ms: this.options.turn?.maxWaitMs
        }
      }
    });
  }
  flushPlayback() {
    this.duplex?.port.postMessage({ flush: !0 });
  }
  pushHistory() {
    this.send({ type: "conversation.history", messages: this.history }), this.handlers.history?.(this.history);
  }
  // Closes the answer in flight with what was actually heard. A unit counts
  // once its audio started playing: a barge-in keeps the sentence it cut and
  // drops the ones still queued, so the model never believes it said more.
  closeAnswer() {
    const t = this.units.filter((e) => e.start < this.playedSamples).map((e) => e.text).join(" ").trim();
    this.units = [], this.answerDone = !1, t && (this.history.push({ role: "assistant", content: t }), this.pushHistory());
  }
  connect() {
    return new Promise((t, e) => {
      const s = p(this.options.url), i = new WebSocket(s);
      this.ws = i, this.log(`Connecting to ${s}`), i.onopen = () => {
        this.log("Connected"), this.sendSessionUpdate(), this.pushHistory(), t();
      }, i.onerror = () => {
        this.log(`Connection to ${s} failed`), e(new Error(`cannot reach ${s}`));
      }, i.onclose = (n) => {
        this.log(`Connection closed, code ${n.code}`), this.ws = null, this.setState("idle");
      }, i.onmessage = (n) => this.onServerEvent(n.data);
    });
  }
  onServerEvent(t) {
    let e;
    try {
      e = JSON.parse(t);
    } catch {
      return;
    }
    switch (e.type) {
      case "input_audio_buffer.speech_started":
        (this.state === "speaking" || this.state === "thinking") && (this.flushPlayback(), this.closeAnswer()), this.setState("listening");
        break;
      case "conversation.item.input_audio_transcription.completed":
        {
          const s = String(e.transcript ?? "");
          this.history.push({ role: "user", content: s }), this.handlers.user_text?.(s);
        }
        break;
      case "response.created":
        this.closeAnswer(), this.generation++, this.queuedSamples = 0, this.playedSamples = 0, this.duplex?.port.postMessage({ reset: this.generation }), this.setState("thinking");
        break;
      case "response.output_text.delta":
        this.handlers.assistant_delta?.(String(e.delta ?? ""));
        break;
      case "response.output_audio_transcript.delta":
        {
          const s = String(e.delta ?? "");
          this.units.push({ text: s, start: this.queuedSamples }), this.handlers.assistant_text?.(s);
        }
        break;
      case "response.output_audio.delta":
        {
          const s = u(String(e.delta ?? ""));
          this.queuedSamples += s.length, this.duplex?.port.postMessage(s), this.setState("speaking");
        }
        break;
      case "response.cancelled":
        this.flushPlayback(), this.closeAnswer(), this.setState("listening");
        break;
      case "response.done":
        this.answerDone = !0, this.playedSamples >= this.queuedSamples && (this.closeAnswer(), this.setState("listening"));
        break;
      case "error":
        {
          const s = e.error;
          this.handlers.error?.(s?.message ?? "unknown error");
        }
        break;
    }
  }
}
export {
  h as ECHO_DEFAULT,
  d as ECHO_MODES,
  m as S2S,
  p as realtimeUrl
};
