const y = ["client", "server", "both", "off"], u = "client";
const d = `
const RATIO = sampleRate / 24000; // device samples per protocol sample
const SMOOTH = RATIO > 1;

class DuplexProcessor extends AudioWorkletProcessor {
	constructor() {
		super();
		this.mic = new Float32Array(480);
		this.ref = new Float32Array(480);
		this.filled = 0;
		this.muted = false;
		this.volume = 1;
		this.queue = [];
		this.offset = 0;
		this.played = 0;
		this.generation = 0;
		// playback: the two protocol samples the output lies between, and how
		// far past the first, in protocol samples
		this.a = 0;
		this.b = 0;
		this.at = 1;
		// capture: the last raw and the last smoothed device sample of each
		// side, and where the next protocol sample falls past the smoothed
		// one, in device samples
		this.rawMic = 0;
		this.rawRef = 0;
		this.prevMic = 0;
		this.prevRef = 0;
		this.next = 1;
		this.port.onmessage = (e) => {
			const data = e.data;
			if (data instanceof Float32Array) {
				this.queue.push(data);
			} else if (data.flush) {
				this.queue = [];
				this.offset = 0;
				this.a = 0;
				this.b = 0;
			} else if (data.reset !== undefined) {
				this.played = 0;
				this.generation = data.reset;
			} else if (data.muted !== undefined) {
				this.muted = data.muted;
			} else if (data.volume !== undefined) {
				this.volume = data.volume;
			}
		};
	}
	// The next protocol sample of the answer, silence once the queue is dry.
	pull() {
		if (this.queue.length === 0) {
			return 0;
		}
		const chunk = this.queue[0];
		const sample = chunk[this.offset++];
		this.played++;
		if (this.offset === chunk.length) {
			this.queue.shift();
			this.offset = 0;
		}
		return sample;
	}
	capture(mic, ref) {
		if (SMOOTH) {
			const m = mic;
			const r = ref;
			mic = (mic + this.rawMic) * 0.5;
			ref = (ref + this.rawRef) * 0.5;
			this.rawMic = m;
			this.rawRef = r;
		}
		while (this.next <= 1) {
			this.mic[this.filled] = this.prevMic + (mic - this.prevMic) * this.next;
			this.ref[this.filled] = this.prevRef + (ref - this.prevRef) * this.next;
			if (++this.filled === this.mic.length) {
				this.port.postMessage({ mic: this.mic.slice(), ref: this.ref.slice() });
				this.filled = 0;
			}
			this.next += RATIO;
		}
		this.next -= 1;
		this.prevMic = mic;
		this.prevRef = ref;
	}
	process(inputs, outputs) {
		const output = outputs[0][0];
		const input = inputs[0] && inputs[0][0];
		const played = this.played;
		for (let i = 0; i < output.length; i++) {
			while (this.at >= 1) {
				this.a = this.b;
				this.b = this.pull();
				this.at -= 1;
			}
			output[i] = (this.a + (this.b - this.a) * this.at) * this.volume;
			this.at += 1 / RATIO;
			this.capture(input && !this.muted ? input[i] : 0, output[i]);
		}
		if (this.played !== played) {
			this.port.postMessage({ played: this.played, generation: this.generation });
		}
		return true;
	}
}
registerProcessor('s2s-duplex', DuplexProcessor);
`;
function m() {
  const o = new Intl.DisplayNames(["en"], { type: "language" }), s = navigator.languages.map((t) => o.of(t.split("-")[0])?.toLowerCase());
  return [...new Set(s.filter((t) => !!t))];
}
function f(o) {
  const s = new URL("v1/realtime", o ? o.replace(/\/?$/, "/") : location.href);
  return s.protocol = s.protocol === "https:" ? "wss:" : s.protocol === "http:" ? "ws:" : s.protocol, s.toString();
}
function c(o) {
  let s = 0;
  for (let t = 0; t < o.length; t++)
    s = Math.max(s, Math.abs(o[t]));
  return s;
}
function h(o, s) {
  const t = l(o);
  return {
    ...s ? { deviceId: { exact: s } } : {},
    echoCancellation: o === "client" || o === "both" ? "all" : !1,
    noiseSuppression: !t,
    autoGainControl: !t,
    channelCount: 1
  };
}
function l(o) {
  return o === "server" || o === "both";
}
function g(o) {
  return URL.createObjectURL(new Blob([o], { type: "application/javascript" }));
}
function p(o) {
  const s = new Uint8Array(o.length * 2), t = new DataView(s.buffer);
  for (let i = 0; i < o.length; i++) {
    const n = Math.max(-1, Math.min(1, o[i]));
    t.setInt16(i * 2, n * 32767, !0);
  }
  let e = "";
  for (let i = 0; i < s.length; i += 32768)
    e += String.fromCharCode(...s.subarray(i, i + 32768));
  return btoa(e);
}
function w(o) {
  const s = atob(o), t = new Uint8Array(s.length);
  for (let n = 0; n < s.length; n++)
    t[n] = s.charCodeAt(n);
  const e = new DataView(t.buffer), i = new Float32Array(t.length / 2);
  for (let n = 0; n < i.length; n++)
    i[n] = e.getInt16(n * 2, !0) / 32768;
  return i;
}
class S {
  options;
  handlers = {};
  ws = null;
  context = null;
  stream = null;
  source = null;
  duplex = null;
  volume = 1;
  input = 0;
  output = 0;
  state = "idle";
  // The answer in flight, measured in samples since its response.created:
  // what the server sent, what the speaker played, and each synthesis unit
  // with the sample where its audio starts. The generation tags the played
  // reports, so a report of a previous answer is ignored.
  generation = 0;
  queuedSamples = 0;
  playedSamples = 0;
  units = [];
  answerDone = !1;
  answering = !1;
  // between response.created and its close
  history = [];
  userItem = "";
  // the server item of the last user message
  // Bumped by every start and every teardown: a start that a stop overtook,
  // or a socket of an earlier run, sees a different number and backs off.
  run = 0;
  established = !1;
  // a connection of this run opened
  reconnectTimer;
  constructor(s) {
    this.options = s;
  }
  on(s, t) {
    this.handlers[s] = t;
  }
  getState() {
    return this.state;
  }
  // The peaks of the last 20 ms, linear from 0 to 1: input is what the
  // microphone sends, silent while muted, output is what plays, volume
  // applied. Both read 0 while idle.
  levels() {
    return this.state === "idle" ? { input: 0, output: 0 } : { input: this.input, output: this.output };
  }
  // Must be called from a user gesture: browsers refuse both the microphone
  // and an audio context without one.
  async start() {
    if (this.context)
      return;
    const s = ++this.run;
    try {
      await this.open(s);
    } catch (t) {
      if (s !== this.run)
        return;
      const e = t instanceof Error ? `${t.name}: ${t.message}` : String(t);
      throw this.log(`Start failed, ${e}`), this.handlers.error?.(e), this.teardown(), t;
    }
  }
  log(s) {
    this.handlers.log?.(s);
  }
  // Every await is a point where a stop may have come in: the run number
  // says so, and what was acquired meanwhile is released on the spot.
  async open(s) {
    if (this.log("Start requested"), !window.isSecureContext) {
      const i = new Error("HTTPS required for the microphone");
      throw i.name = "SecurityError", i;
    }
    const t = new AudioContext();
    if (this.context = t, await t.audioWorklet.addModule(g(d)), s !== this.run)
      return;
    this.log(`Audio context at ${t.sampleRate} Hz`);
    const e = await navigator.mediaDevices.getUserMedia({
      audio: h(this.echo(), this.options.mic)
    });
    if (s !== this.run) {
      e.getTracks().forEach((i) => i.stop());
      return;
    }
    this.stream = e, this.log(`Microphone granted, ${this.micApplied()}`), this.duplex = new AudioWorkletNode(t, "s2s-duplex", {
      numberOfInputs: 1,
      numberOfOutputs: 1,
      outputChannelCount: [1]
    }), this.duplex.port.postMessage({ volume: this.volume }), this.duplex.port.onmessage = (i) => {
      if (i.data.mic) {
        this.input = c(i.data.mic), this.output = c(i.data.ref), this.sendAudio(i.data.mic, i.data.ref);
        return;
      }
      i.data.generation === this.generation && (this.playedSamples = i.data.played, this.answerDone && this.playedSamples >= this.queuedSamples && (this.closeAnswer(), this.setState("listening")));
    }, this.source = t.createMediaStreamSource(e), this.source.connect(this.duplex), this.duplex.connect(t.destination), await this.connect(s), s === this.run && this.setState("listening");
  }
  stop() {
    this.log("Stop requested"), this.teardown();
  }
  // Releases the socket, the microphone and the audio context, whoever ends
  // the session: the user, a failed start or the server closing. The answer
  // in flight closes first, so what was heard stays in the conversation, and
  // the turn identity goes: the next connection numbers its turns afresh,
  // so no line keeps the item of a turn that no longer exists.
  teardown() {
    this.closeAnswer(), this.forgetTurns(), clearTimeout(this.reconnectTimer), this.established = !1, this.run++;
    const s = this.ws;
    this.ws = null, s?.close(), this.stream?.getTracks().forEach((t) => t.stop()), this.stream = null, this.source = null, this.context?.close(), this.context = null, this.duplex = null, this.setState("idle");
  }
  forgetTurns() {
    this.userItem = "", this.history = this.history.map(({ role: s, content: t }) => ({ role: s, content: t }));
  }
  // Keeps the microphone and the playback up and tries a new socket until
  // one opens or the session stops.
  reconnect(s) {
    this.ws = null, this.flushPlayback(), this.closeAnswer(), this.forgetTurns(), this.setState("listening"), this.log("Reconnecting in 1000 ms"), this.reconnectTimer = setTimeout(() => {
      s === this.run && this.connect(s).catch(() => {
      });
    }, 1e3);
  }
  setVolume(s) {
    this.volume = s, this.duplex?.port.postMessage({ volume: s });
  }
  mute(s) {
    this.duplex?.port.postMessage({ muted: s });
  }
  // Client side barge-in: the user took the floor, so playback stops now and
  // the server stops the response. The answer closes right here with what
  // was actually heard; whatever the server still sends for it, audio, text
  // or its terminal, finds it closed and changes nothing.
  cancel() {
    this.send({ type: "response.cancel" }), this.flushPlayback(), this.closeAnswer(), this.setState("listening");
  }
  getHistory() {
    return this.history;
  }
  // Seeds the conversation, for a host that persisted it or that brings its
  // own context.
  setHistory(s) {
    this.history = s.map(({ role: t, content: e }) => ({ role: t, content: e })), this.userItem = "", this.pushHistory();
  }
  // Forgets the conversation. An answer in flight goes with it: the server
  // stops it, the speaker falls silent, and nothing of it is filed or shown,
  // so whatever the server still sends for it finds it closed.
  clearHistory() {
    this.log("History cleared"), this.answering && (this.send({ type: "response.cancel" }), this.flushPlayback(), this.units = [], this.answerDone = !1, this.answering = !1, this.setState("listening")), this.setHistory([]);
  }
  // A key given replaces its value, undefined included, and a field left
  // undefined takes the server default: every session.update describes the
  // whole session. A key left out of options keeps its value.
  update(s) {
    const t = this.echo(), e = this.options.mic;
    Object.assign(this.options, s), this.sendSessionUpdate(), this.stream && this.options.mic !== e ? this.applyMic() : this.stream && this.echo() !== t && this.applyEcho();
  }
  // A track never changes device: another microphone is a new stream,
  // opened with the constraints of the method in force, that takes the
  // place of the previous one in front of the worklet.
  async applyMic() {
    const s = this.run;
    try {
      const t = await navigator.mediaDevices.getUserMedia({
        audio: h(this.echo(), this.options.mic)
      });
      if (s !== this.run || !this.context || !this.duplex) {
        t.getTracks().forEach((e) => e.stop());
        return;
      }
      this.stream?.getTracks().forEach((e) => e.stop()), this.source?.disconnect(), this.stream = t, this.source = this.context.createMediaStreamSource(t), this.source.connect(this.duplex), this.log(`Microphone switched, ${this.micApplied()}`);
    } catch (t) {
      const e = `Microphone switch refused, ${t instanceof Error ? `${t.name}: ${t.message}` : String(t)}`;
      this.log(e), this.handlers.error?.(e);
    }
  }
  // The server switches its canceller on the session.update; the microphone
  // follows here, so the browser processing always matches the method.
  applyEcho() {
    this.stream?.getAudioTracks()[0]?.applyConstraints(h(this.echo())).then(() => this.log(`Microphone switched, ${this.micApplied()}`)).catch((t) => {
      const e = `Microphone switch refused, ${t instanceof Error ? t.message : String(t)}`;
      this.log(e), this.handlers.error?.(e);
    });
  }
  // What really runs on the microphone: the device, the server canceller,
  // and what the browser applies, which is not always what was asked.
  micApplied() {
    const s = this.stream?.getAudioTracks()[0], t = s?.getSettings();
    return `device ${s?.label}, server echo cancellation ${l(this.echo())}, browser echo cancellation ${t?.echoCancellation}, noise suppression ${t?.noiseSuppression}, gain control ${t?.autoGainControl}`;
  }
  setState(s) {
    this.state !== s && (this.state = s, this.handlers.state?.(s));
  }
  send(s) {
    this.ws && this.ws.readyState === WebSocket.OPEN && this.ws.send(JSON.stringify(s));
  }
  // The reference only travels to a server canceller, and only when the
  // frame played something: silence is what its absence means.
  sendAudio(s, t) {
    const e = l(this.echo()) && t.some((i) => i !== 0);
    this.send({
      type: "input_audio_buffer.append",
      audio: p(s),
      ...e ? { reference: p(t) } : {}
    });
  }
  echo() {
    return this.options.echo ?? u;
  }
  sendSessionUpdate() {
    this.send({
      type: "session.update",
      session: {
        mode: this.options.mode,
        echo: this.echo(),
        instructions: this.options.instructions,
        llm_url: this.options.llmUrl,
        llm_model: this.options.llmModel,
        llm_key: this.options.llmKey,
        llm_timeout_sec: this.options.llmTimeoutSec,
        tools: this.options.tools,
        mcp: this.options.mcp,
        max_rounds: this.options.maxRounds,
        tool_timeout_sec: this.options.toolTimeoutSec,
        sampling: {
          temperature: this.options.sampling?.temperature,
          top_p: this.options.sampling?.topP,
          top_k: this.options.sampling?.topK,
          min_p: this.options.sampling?.minP,
          max_tokens: this.options.sampling?.maxTokens,
          presence_penalty: this.options.sampling?.presencePenalty,
          frequency_penalty: this.options.sampling?.frequencyPenalty,
          seed: this.options.sampling?.seed,
          reasoning_effort: this.options.sampling?.reasoningEffort
        },
        tts: {
          voice: this.options.tts?.voice,
          effect: this.options.tts?.effect,
          language: this.options.tts?.language,
          browser_languages: m(),
          min_chars: this.options.tts?.minChars,
          chars_per_second: this.options.tts?.charsPerSecond,
          margin_seconds: this.options.tts?.marginSeconds,
          sampling: {
            temperature: this.options.tts?.sampling?.temperature,
            top_k: this.options.tts?.sampling?.topK,
            top_p: this.options.tts?.sampling?.topP,
            repetition_penalty: this.options.tts?.sampling?.repetitionPenalty,
            subtalker_temperature: this.options.tts?.sampling?.subtalkerTemperature,
            subtalker_top_k: this.options.tts?.sampling?.subtalkerTopK,
            subtalker_top_p: this.options.tts?.sampling?.subtalkerTopP,
            max_new_tokens: this.options.tts?.sampling?.maxNewTokens,
            seed: this.options.tts?.sampling?.seed
          }
        },
        vad: {
          neg_threshold: this.options.vad?.negThreshold,
          threshold: this.options.vad?.threshold,
          min_speech_ms: this.options.vad?.minSpeechMs,
          barge_in_ms: this.options.vad?.bargeInMs,
          min_silence_ms: this.options.vad?.minSilenceMs,
          min_speech_continuation_ms: this.options.vad?.minSpeechContinuationMs,
          speech_pad_ms: this.options.vad?.speechPadMs
        },
        turn: {
          threshold: this.options.turn?.threshold,
          incomplete_delay_ms: this.options.turn?.incompleteDelayMs,
          max_wait_ms: this.options.turn?.maxWaitMs,
          reopen_grace_ms: this.options.turn?.graceMs
        }
      }
    });
  }
  flushPlayback() {
    this.duplex?.port.postMessage({ flush: !0 });
  }
  pushHistory() {
    this.send({ type: "conversation.history", messages: this.history }), this.handlers.history?.(this.history);
  }
  // Closes the answer in flight with what was actually heard. A unit counts
  // once its audio started playing: a barge-in keeps the sentence it cut and
  // drops the ones still queued, so the model never believes it said more.
  // An answer with nothing heard is not filed, empty or cut before a word,
  // and the turn it answered reaches the server joined to the next one: a
  // silence filed as an answer is one the model imitates. Every close
  // pushes the list.
  closeAnswer() {
    if (!this.answering)
      return;
    const s = this.answerDone, t = this.units.filter((e) => e.start < this.playedSamples).map((e) => e.text).join(" ").trim();
    this.units = [], this.answerDone = !1, this.answering = !1, t && this.history.push({ role: "assistant", content: t }), s && this.handlers.assistant_done?.(), this.pushHistory();
  }
  connect(s) {
    return new Promise((t, e) => {
      const i = f(this.options.url), n = new WebSocket(i);
      this.ws = n, this.log(`Connecting to ${i}`);
      let a = !1;
      n.onopen = () => {
        this.log(this.established ? "Reconnected" : "Connected"), a = !0, this.established = !0, this.sendSessionUpdate(), this.pushHistory(), t();
      }, n.onerror = () => {
        this.log(`Connection to ${i} failed`), e(new Error(`cannot reach ${i}`));
      }, n.onclose = (r) => {
        if (!(n !== this.ws || s !== this.run)) {
          if (this.log(`Connection closed, code ${r.code}`), r.wasClean || !this.established) {
            r.wasClean || this.handlers.error?.(`Connection lost, code ${r.code}`), this.teardown();
            return;
          }
          a && this.handlers.error?.(`Connection lost, code ${r.code}, reconnecting`), this.reconnect(s);
        }
      }, n.onmessage = (r) => this.onServerEvent(r.data);
    });
  }
  onServerEvent(s) {
    let t;
    try {
      t = JSON.parse(s);
    } catch {
      return;
    }
    switch (t.type) {
      case "session.updated":
        {
          const e = t.session, i = e?.tts?.voice, n = e?.tts?.effect;
          typeof i == "string" && typeof n == "string" && (this.options.tts = { ...this.options.tts, voice: i, effect: n }, this.log(`Voice set to ${i}, effect ${n}`), this.handlers.voice?.(i, n));
        }
        break;
      case "input_audio_buffer.speech_started":
        (this.state === "speaking" || this.state === "thinking") && (this.flushPlayback(), this.closeAnswer()), this.setState("listening");
        break;
      case "conversation.item.input_audio_transcription.completed":
        {
          const e = String(t.transcript ?? ""), i = String(t.item_id ?? ""), n = this.history[this.history.length - 1], a = i !== "" && i === this.userItem && n?.role === "user";
          a ? n.content = e : this.history.push({ role: "user", content: e, item: i }), this.userItem = i, this.handlers.user_text?.(e, a);
        }
        break;
      case "response.created":
        this.closeAnswer(), this.answering = !0, this.answerDone = !1, this.generation++, this.queuedSamples = 0, this.playedSamples = 0, this.duplex?.port.postMessage({ reset: this.generation }), this.setState("thinking");
        break;
      // An answer the client already closed takes nothing more.
      case "response.output_text.delta":
        this.answering && this.handlers.assistant_delta?.(String(t.delta ?? ""));
        break;
      case "response.output_audio_transcript.delta":
        if (this.answering) {
          const e = String(t.delta ?? "");
          this.units.push({ text: e, start: this.queuedSamples }), this.handlers.assistant_text?.(e, Number(t.text_end ?? 0));
        }
        break;
      case "response.output_audio.delta":
        if (this.answering) {
          const e = w(String(t.delta ?? ""));
          this.queuedSamples += e.length, this.duplex?.port.postMessage(e), this.setState("speaking");
        }
        break;
      case "response.cancelled":
        this.flushPlayback(), this.closeAnswer(), this.setState("listening");
        break;
      case "response.done":
        this.answerDone = !0, this.playedSamples >= this.queuedSamples && (this.closeAnswer(), this.setState("listening"));
        break;
      case "error":
        {
          const e = t.error;
          this.handlers.error?.(e?.message ?? "unknown error");
        }
        break;
    }
  }
}
export {
  u as ECHO_DEFAULT,
  y as ECHO_MODES,
  S as S2S
};
